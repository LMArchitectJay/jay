export interface AIConfig {
  provider: 'openai' | 'groq' | 'gemini' | 'openrouter';
  apiKey: string;
  model: string;
}

interface ModelInfo {
  id: string;
  label: string;
  note: string;
}

interface ProviderInfo {
  models: ModelInfo[];
}

const PROVIDERS: Record<string, ProviderInfo> = {
  gemini: {
    models: [
      { id: 'gemini-2.5-flash', label: 'Gemini 2.5 Flash', note: '⭐ Best free option — huge token limit' },
      { id: 'gemini-2.5-pro', label: 'Gemini 2.5 Pro', note: 'Most powerful (limited free RPM)' },
      { id: 'gemini-2.5-flash-lite', label: 'Gemini 2.5 Flash Lite', note: 'Lightweight & fast' },
      { id: 'gemini-2.0-flash', label: 'Gemini 2.0 Flash', note: 'Fast & reliable' },
      { id: 'gemini-2.0-flash-lite', label: 'Gemini 2.0 Flash Lite', note: 'Budget friendly' },
    ],
  },
  groq: {
    models: [
      { id: 'llama-3.3-70b-versatile', label: 'Llama 3.3 70B', note: '⭐ Best quality — 300K TPM dev tier' },
      { id: 'llama-3.1-8b-instant', label: 'Llama 3.1 8B Instant', note: 'Fastest — 250K TPM, 131K context' },
      { id: 'meta-llama/llama-4-scout-17b-16e-instruct', label: 'Llama 4 Scout 17B', note: 'NEW — 300K TPM, 131K context' },
      { id: 'qwen/qwen3-32b', label: 'Qwen 3 32B', note: 'Strong reasoning — 300K TPM' },
      { id: 'openai/gpt-oss-120b', label: 'GPT-OSS 120B', note: 'OpenAI open-weight — 250K TPM' },
      { id: 'openai/gpt-oss-20b', label: 'GPT-OSS 20B', note: 'Lightweight OpenAI — 250K TPM' },
      { id: 'gemma2-9b-it', label: 'Gemma 2 9B', note: 'Google — 15K TPM free' },
      { id: 'mixtral-8x7b-32768', label: 'Mixtral 8x7B', note: 'Mistral MoE — 5K TPM free' },
    ],
  },
  openai: {
    models: [
      { id: 'gpt-4.1', label: 'GPT-4.1', note: '⭐ Latest flagship — best for coding' },
      { id: 'gpt-4.1-mini', label: 'GPT-4.1 Mini', note: 'Fast & affordable' },
      { id: 'gpt-4.1-nano', label: 'GPT-4.1 Nano', note: 'Ultra cheap & fast' },
      { id: 'gpt-4o', label: 'GPT-4o', note: 'Previous flagship — very capable' },
      { id: 'gpt-4o-mini', label: 'GPT-4o Mini', note: 'Budget friendly' },
      { id: 'o4-mini', label: 'o4-mini', note: 'Reasoning model — thinks step by step' },
      { id: 'o3-mini', label: 'o3-mini', note: 'Previous reasoning model' },
      { id: 'gpt-3.5-turbo', label: 'GPT-3.5 Turbo', note: 'Legacy — cheapest option' },
    ],
  },
  openrouter: {
    models: [
      { id: 'meta-llama/llama-3.3-70b-instruct:free', label: 'Llama 3.3 70B', note: '🆓 FREE — GPT-4 level, 65K ctx' },
      { id: 'mistralai/devstral-2512:free', label: 'Devstral 2 (123B)', note: '🆓 FREE — Best free coding model' },
      { id: 'nvidia/llama-3.1-nemotron-3-super-49b-v1:free', label: 'Nemotron 3 Super', note: '🆓 FREE — 262K ctx, NVIDIA' },
      { id: 'nvidia/llama-3.1-nemotron-3-1-nano-12b-v1:free', label: 'Nemotron 3 Nano 12B', note: '🆓 FREE — fast reasoning' },
      { id: 'openai/gpt-oss-120b:free', label: 'GPT-OSS 120B', note: '🆓 FREE — OpenAI open-weight' },
      { id: 'openai/gpt-oss-20b:free', label: 'GPT-OSS 20B', note: '🆓 FREE — lightweight OpenAI' },
      { id: 'deepseek/deepseek-r1-0528:free', label: 'DeepSeek R1', note: '🆓 FREE — strong reasoning, 164K ctx' },
      { id: 'qwen/qwen3-coder:free', label: 'Qwen 3 Coder (480B)', note: '🆓 FREE — huge coding model' },
      { id: 'qwen/qwen3-next-80b-a3b-instruct:free', label: 'Qwen 3 Next 80B', note: '🆓 FREE — RAG & agents' },
      { id: 'nousresearch/hermes-3-llama-3.1-405b:free', label: 'Hermes 3 405B', note: '🆓 FREE — largest free model' },
      { id: 'google/gemma-3-27b-it:free', label: 'Gemma 3 27B', note: '🆓 FREE — Google multimodal' },
      { id: 'google/gemma-3-12b-it:free', label: 'Gemma 3 12B', note: '🆓 FREE — mid-size Google' },
      { id: 'google/gemma-3-4b-it:free', label: 'Gemma 3 4B', note: '🆓 FREE — compact & fast' },
      { id: 'mistralai/mistral-small-3.1-24b-instruct:free', label: 'Mistral Small 3.1', note: '🆓 FREE — 128K ctx' },
      { id: 'meta-llama/llama-3.2-3b-instruct:free', label: 'Llama 3.2 3B', note: '🆓 FREE — ultra lightweight' },
      { id: 'arcee-ai/arcee-trinity-large:free', label: 'Arcee Trinity Large', note: '🆓 FREE — 400B MoE reasoning' },
      { id: 'arcee-ai/arcee-trinity-mini:free', label: 'Arcee Trinity Mini', note: '🆓 FREE — fast 26B MoE' },
      { id: 'zhipu-ai/glm-4.5-air:free', label: 'GLM 4.5 Air', note: '🆓 FREE — strong multilingual' },
      { id: 'stepfun/step-3.5-flash:free', label: 'Step 3.5 Flash', note: '🆓 FREE — 196B MoE, 256K ctx' },
      { id: 'openai/gpt-4o-mini', label: 'GPT-4o Mini', note: '💰 PAID — OpenAI via OpenRouter' },
      { id: 'openai/gpt-4o', label: 'GPT-4o', note: '💰 PAID — OpenAI via OpenRouter' },
      { id: 'anthropic/claude-sonnet-4', label: 'Claude Sonnet 4', note: '💰 PAID — Anthropic top tier' },
      { id: 'google/gemini-2.5-flash', label: 'Gemini 2.5 Flash', note: '💰 PAID — Google via OpenRouter' },
      { id: 'google/gemini-2.5-pro', label: 'Gemini 2.5 Pro', note: '💰 PAID — Google top tier' },
    ],
  },
};

export function getProviderModels(provider: string): ModelInfo[] {
  return PROVIDERS[provider]?.models ?? [];
}

export function estimateTokens(text: string): number {
  return Math.ceil(text.length / 3.5);
}

const SYSTEM_PROMPT = `You are an expert Roblox Studio Lua / Luau script developer. You help users create, edit, fix, and improve scripts for Roblox Studio.

CRITICAL RULES:
1. When the user gives you an EXISTING SCRIPT and asks for changes, you MUST return the FULL COMPLETE script with ALL changes applied. Do NOT return only the changed parts. Do NOT skip any sections. Return the ENTIRE script from start to finish with the modifications integrated into the correct places.
2. Output ONLY the Lua code. No explanations, no markdown code fences, no comments about what you changed (unless the user asks for comments). Just pure Lua code ready to paste into Roblox Studio.
3. Use proper Roblox API conventions: game:GetService(), Instance.new(), proper event connections, etc.
4. Use Luau features when appropriate (type annotations, string interpolation, etc).
5. Write clean, well-structured, properly indented code.
6. Never truncate or shorten the script. If the original script is 500 lines, the output should be approximately 500 lines (plus or minus whatever you add/remove).
7. Do NOT add \`\`\`lua or \`\`\` markers. Output raw code only.
8. When editing, make ONLY the changes the user asked for. Do not refactor or change other parts of the script unless specifically asked.`;

function buildUserMessage(userPrompt: string, existingCode: string | null): string {
  if (existingCode) {
    return `Here is my current Roblox Studio script:\n\n${existingCode}\n\n---\n\nPlease make the following changes and return the FULL COMPLETE updated script with ALL lines included:\n\n${userPrompt}`;
  }
  return `Create a Roblox Studio Lua script for the following:\n\n${userPrompt}`;
}

function cleanOutput(text: string): string {
  let cleaned = text;
  cleaned = cleaned.replace(/^```(?:lua|luau)?\s*\n?/, '');
  cleaned = cleaned.replace(/\n?```\s*$/, '');
  return cleaned.trim();
}

function formatError(status: number, message: string, provider: string): string {
  if (message.toLowerCase().includes('token') || message.toLowerCase().includes('too large') || message.toLowerCase().includes('limit') || message.toLowerCase().includes('rate')) {
    if (provider === 'groq') {
      return `⚠️ GROQ TOKEN LIMIT HIT\n\n${message}\n\n💡 HOW TO FIX:\n• Switch to Google Gemini (free, handles huge scripts)\n• Switch to OpenRouter (many free models with high limits)\n• Or use "Llama 3.1 8B" model (131k TPM free vs 12k on 70B)\n• Or upgrade your Groq plan at console.groq.com/settings/billing`;
    }
    if (provider === 'openai') {
      return `⚠️ OPENAI TOKEN LIMIT HIT\n\n${message}\n\n💡 HOW TO FIX:\n• Switch to Google Gemini (free, handles huge scripts)\n• Switch to OpenRouter (many free models)\n• Or use a model with higher limits (gpt-4o-mini is cheaper)`;
    }
    if (provider === 'openrouter') {
      return `⚠️ OPENROUTER RATE LIMIT HIT\n\n${message}\n\n💡 HOW TO FIX:\n• Wait a minute and try again\n• Try a different free model\n• Switch to Google Gemini (free with high limits)\n• Or add credits on openrouter.ai to bypass free limits`;
    }
    return `⚠️ TOKEN LIMIT HIT\n\n${message}\n\n💡 Try switching to Google Gemini or OpenRouter — both have free tiers that handle large scripts.`;
  }

  if (status === 401 || status === 403) {
    return `🔑 INVALID API KEY\n\nYour ${provider} API key was rejected. Please check:\n• The key is correct and not expired\n• You're using a key for the right provider\n• Go to Settings (gear icon) to update your key`;
  }

  return `Error (${status}): ${message}`;
}

// ====== OPENAI / GROQ / OPENROUTER STREAMING (same OpenAI-compatible format) ======
async function streamOpenAICompatible(
  url: string,
  apiKey: string,
  model: string,
  userMessage: string,
  provider: string,
  onChunk: (text: string) => void,
  onDone: () => void,
  onError: (error: string) => void,
  extraHeaders?: Record<string, string>,
) {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${apiKey}`,
    ...extraHeaders,
  };

  const body: Record<string, unknown> = {
    model,
    messages: [
      { role: 'system', content: SYSTEM_PROMPT },
      { role: 'user', content: userMessage },
    ],
    stream: true,
    temperature: 0.3,
    max_tokens: 16384,
  };

  // For reasoning models (o3/o4), don't set temperature & use different max
  if (model.startsWith('o3') || model.startsWith('o4')) {
    delete body.temperature;
    delete body.max_tokens;
    body.max_completion_tokens = 16384;
  }

  const response = await fetch(url, {
    method: 'POST',
    headers,
    body: JSON.stringify(body),
  });

  if (!response.ok) {
    const errorBody = await response.text();
    let msg = `API Error (${response.status})`;
    try {
      const parsed = JSON.parse(errorBody);
      msg = parsed?.error?.message || parsed?.error?.metadata?.raw || msg;
    } catch {
      msg = errorBody || msg;
    }
    onError(formatError(response.status, msg, provider));
    return;
  }

  const reader = response.body?.getReader();
  if (!reader) {
    onError('No response stream available.');
    return;
  }

  const decoder = new TextDecoder();
  let buffer = '';
  let fullText = '';

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split('\n');
    buffer = lines.pop() || '';

    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed || !trimmed.startsWith('data: ')) continue;
      const data = trimmed.slice(6);
      if (data === '[DONE]') continue;

      try {
        const parsed = JSON.parse(data);
        const content = parsed.choices?.[0]?.delta?.content;
        if (content) {
          fullText += content;
          onChunk(fullText);
        }
      } catch {
        // skip malformed chunk
      }
    }
  }

  const cleaned = cleanOutput(fullText);
  onChunk(cleaned);
  onDone();
}

// ====== GEMINI STREAMING (SSE) ======
async function streamGemini(
  apiKey: string,
  model: string,
  userMessage: string,
  onChunk: (text: string) => void,
  onDone: () => void,
  onError: (error: string) => void,
) {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:streamGenerateContent?alt=sse&key=${apiKey}`;

  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      system_instruction: {
        parts: [{ text: SYSTEM_PROMPT }],
      },
      contents: [
        {
          role: 'user',
          parts: [{ text: userMessage }],
        },
      ],
      generationConfig: {
        temperature: 0.3,
        maxOutputTokens: 65536,
      },
    }),
  });

  if (!response.ok) {
    const errorBody = await response.text();
    let msg = `API Error (${response.status})`;
    try {
      const parsed = JSON.parse(errorBody);
      msg = parsed?.error?.message || msg;
    } catch {
      // use default
    }
    onError(formatError(response.status, msg, 'gemini'));
    return;
  }

  const reader = response.body?.getReader();
  if (!reader) {
    onError('No response stream available.');
    return;
  }

  const decoder = new TextDecoder();
  let buffer = '';
  let fullText = '';

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split('\n');
    buffer = lines.pop() || '';

    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed || !trimmed.startsWith('data: ')) continue;
      const data = trimmed.slice(6);
      if (data === '[DONE]') continue;

      try {
        const parsed = JSON.parse(data);
        const textPart = parsed?.candidates?.[0]?.content?.parts?.[0]?.text;
        if (textPart) {
          fullText += textPart;
          onChunk(fullText);
        }
      } catch {
        // skip malformed chunk
      }
    }
  }

  const cleaned = cleanOutput(fullText);
  onChunk(cleaned);
  onDone();
}

// ====== MAIN ENTRY ======
export async function callAI(
  config: AIConfig,
  userPrompt: string,
  existingCode: string | null,
  onChunk: (text: string) => void,
  onDone: () => void,
  onError: (error: string) => void,
) {
  const userMessage = buildUserMessage(userPrompt, existingCode);
  const estimatedTokens = estimateTokens(SYSTEM_PROMPT + userMessage);

  try {
    if (config.provider === 'gemini') {
      await streamGemini(config.apiKey, config.model, userMessage, onChunk, onDone, onError);
    } else if (config.provider === 'groq') {
      if (config.model === 'llama-3.3-70b-versatile' && estimatedTokens > 10000) {
        onError(
          `⚠️ YOUR SCRIPT IS TOO LARGE FOR THIS MODEL\n\nEstimated ~${estimatedTokens.toLocaleString()} tokens, but Llama 3.3 70B on Groq free tier only allows 12,000 tokens per minute.\n\n💡 HOW TO FIX (pick one):\n• Switch to Google Gemini (free, handles huge scripts — recommended!)\n• Switch to OpenRouter (many free models with high limits)\n• Switch to "Llama 3.1 8B" model in Settings (131k TPM free)\n• Upgrade your Groq plan at console.groq.com/settings/billing`
        );
        return;
      }
      await streamOpenAICompatible(
        'https://api.groq.com/openai/v1/chat/completions',
        config.apiKey,
        config.model,
        userMessage,
        'groq',
        onChunk,
        onDone,
        onError,
      );
    } else if (config.provider === 'openai') {
      await streamOpenAICompatible(
        'https://api.openai.com/v1/chat/completions',
        config.apiKey,
        config.model,
        userMessage,
        'openai',
        onChunk,
        onDone,
        onError,
      );
    } else if (config.provider === 'openrouter') {
      await streamOpenAICompatible(
        'https://openrouter.ai/api/v1/chat/completions',
        config.apiKey,
        config.model,
        userMessage,
        'openrouter',
        onChunk,
        onDone,
        onError,
        {
          'HTTP-Referer': window.location.origin,
          'X-Title': 'Roblox Studio AI Script Helper',
        },
      );
    } else {
      onError('Invalid provider selected.');
    }
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error occurred';
    if (message.includes('Failed to fetch') || message.includes('NetworkError')) {
      onError(`🌐 NETWORK ERROR\n\nCould not connect to the ${config.provider} API.\n\n• Check your internet connection\n• The API may be temporarily down\n• Try again in a moment`);
    } else {
      onError(message);
    }
  }
}
