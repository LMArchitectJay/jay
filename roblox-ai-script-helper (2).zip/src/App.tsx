import { useState, useEffect, useRef, useCallback } from 'react';
import Header from './components/Header';
import Workspace from './components/Workspace';
import OutputPanel from './components/OutputPanel';
import ApiKeyModal from './components/ApiKeyModal';
import { callAI, type AIConfig } from './utils/ai';

const STORAGE_KEY = 'roblox-ai-helper-settings';

function loadSettings(): AIConfig | null {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      const parsed = JSON.parse(stored);
      if (parsed.provider && parsed.apiKey && parsed.model) {
        return parsed as AIConfig;
      }
    }
  } catch {
    // ignore
  }
  return null;
}

function saveSettings(config: AIConfig) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(config));
}

export default function App() {
  const [aiConfig, setAiConfig] = useState<AIConfig | null>(loadSettings);
  const [outputCode, setOutputCode] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const abortRef = useRef(false);

  // Show settings on first visit if no key
  useEffect(() => {
    if (!aiConfig) {
      const timer = setTimeout(() => setSettingsOpen(true), 500);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleSaveSettings = useCallback(
    (provider: 'openai' | 'groq' | 'gemini' | 'openrouter', apiKey: string, model: string) => {
      const config: AIConfig = { provider, apiKey, model };
      setAiConfig(config);
      saveSettings(config);
    },
    []
  );

  const handleGenerate = useCallback(
    (prompt: string) => {
      if (!aiConfig) {
        setSettingsOpen(true);
        return;
      }
      abortRef.current = false;
      setIsGenerating(true);
      setOutputCode('');
      setError(null);

      callAI(
        aiConfig,
        prompt,
        null,
        (text) => {
          if (!abortRef.current) setOutputCode(text);
        },
        () => {
          if (!abortRef.current) setIsGenerating(false);
        },
        (err) => {
          setError(err);
          setIsGenerating(false);
        }
      );
    },
    [aiConfig]
  );

  const handleEdit = useCallback(
    (code: string, prompt: string) => {
      if (!aiConfig) {
        setSettingsOpen(true);
        return;
      }
      abortRef.current = false;
      setIsGenerating(true);
      setOutputCode('');
      setError(null);

      callAI(
        aiConfig,
        prompt,
        code,
        (text) => {
          if (!abortRef.current) setOutputCode(text);
        },
        () => {
          if (!abortRef.current) setIsGenerating(false);
        },
        (err) => {
          setError(err);
          setIsGenerating(false);
        }
      );
    },
    [aiConfig]
  );

  return (
    <div className="h-screen bg-gray-950 text-white flex flex-col font-sans selection:bg-blue-500/30 overflow-hidden">
      <Header
        onOpenSettings={() => setSettingsOpen(true)}
        isConnected={!!aiConfig?.apiKey}
        providerName={aiConfig?.provider || ''}
        modelName={aiConfig?.model || ''}
      />

      <main className="flex-1 container mx-auto p-4 flex flex-col lg:flex-row gap-4 min-h-0">
        <div className="flex-1 flex flex-col min-w-0 h-full">
          <Workspace
            onGenerate={handleGenerate}
            onEdit={handleEdit}
            isGenerating={isGenerating}
            hasApiKey={!!aiConfig?.apiKey}
            onOpenSettings={() => setSettingsOpen(true)}
          />
        </div>
        <div className="flex-1 flex flex-col min-w-0 h-full">
          <OutputPanel
            code={outputCode}
            isGenerating={isGenerating}
            error={error}
          />
        </div>
      </main>

      <ApiKeyModal
        open={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        onSave={handleSaveSettings}
        currentProvider={aiConfig?.provider || 'openrouter'}
        currentModel={aiConfig?.model || ''}
        currentKey={aiConfig?.apiKey || ''}
      />
    </div>
  );
}
