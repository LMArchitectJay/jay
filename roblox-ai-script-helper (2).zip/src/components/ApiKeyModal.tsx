import { useState, useEffect } from 'react';
import { X, Key, ChevronDown, ExternalLink, ShieldCheck, Zap, Sparkles } from 'lucide-react';
import { getProviderModels } from '../utils/ai';

interface ApiKeyModalProps {
  open: boolean;
  onClose: () => void;
  onSave: (provider: 'openai' | 'groq' | 'gemini' | 'openrouter', apiKey: string, model: string) => void;
  currentProvider: string;
  currentModel: string;
  currentKey: string;
}

const PROVIDER_INFO: Record<string, { name: string; tagline: string; keyPrefix: string; keyUrl: string; highlight?: string; color: string }> = {
  openrouter: {
    name: 'OpenRouter',
    tagline: '29 FREE models — no CC needed',
    keyPrefix: 'sk-or-...',
    keyUrl: 'https://openrouter.ai/keys',
    highlight: '🔥 BEST FREE',
    color: 'from-purple-500 to-pink-500',
  },
  gemini: {
    name: 'Google Gemini',
    tagline: 'Free — huge token limits',
    keyPrefix: 'AI...',
    keyUrl: 'https://aistudio.google.com/apikey',
    highlight: '⭐ RECOMMENDED',
    color: 'from-blue-500 to-cyan-500',
  },
  groq: {
    name: 'Groq',
    tagline: 'Free tier — ultra fast',
    keyPrefix: 'gsk_...',
    keyUrl: 'https://console.groq.com/keys',
    color: 'from-orange-500 to-red-500',
  },
  openai: {
    name: 'OpenAI',
    tagline: 'GPT-4.1 & o4 — paid',
    keyPrefix: 'sk-...',
    keyUrl: 'https://platform.openai.com/api-keys',
    color: 'from-green-500 to-emerald-500',
  },
};

const PROVIDERS_ORDER: ('openrouter' | 'gemini' | 'groq' | 'openai')[] = ['openrouter', 'gemini', 'groq', 'openai'];

export default function ApiKeyModal({
  open,
  onClose,
  onSave,
  currentProvider,
  currentModel,
  currentKey,
}: ApiKeyModalProps) {
  const [provider, setProvider] = useState<'openai' | 'groq' | 'gemini' | 'openrouter'>(
    (currentProvider as 'openai' | 'groq' | 'gemini' | 'openrouter') || 'openrouter'
  );
  const [apiKey, setApiKey] = useState(currentKey || '');
  const [model, setModel] = useState(currentModel || '');

  useEffect(() => {
    setProvider((currentProvider as 'openai' | 'groq' | 'gemini' | 'openrouter') || 'openrouter');
    setApiKey(currentKey || '');
    setModel(currentModel || '');
  }, [currentProvider, currentKey, currentModel, open]);

  useEffect(() => {
    const models = getProviderModels(provider);
    if (!models.find((m) => m.id === model)) {
      setModel(models[0]?.id || '');
    }
  }, [provider]);

  if (!open) return null;

  const models = getProviderModels(provider);
  const info = PROVIDER_INFO[provider];

  const handleSave = () => {
    if (!apiKey.trim()) return;
    onSave(provider, apiKey.trim(), model);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="bg-gray-800 rounded-2xl border border-gray-700 shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-700">
          <div className="flex items-center gap-3">
            <div className="bg-blue-600 p-2 rounded-lg">
              <Key className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">AI Settings</h2>
              <p className="text-xs text-gray-400">Choose your AI provider & model</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-700 rounded-lg transition-colors text-gray-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="px-6 py-5 space-y-5">
          {/* Provider Select */}
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">AI Provider</label>
            <div className="grid grid-cols-2 gap-2">
              {PROVIDERS_ORDER.map((p) => {
                const pInfo = PROVIDER_INFO[p];
                return (
                  <button
                    key={p}
                    onClick={() => setProvider(p)}
                    className={`p-3 rounded-xl border-2 text-left transition-all relative ${
                      provider === p
                        ? 'border-blue-500 bg-blue-500/10'
                        : 'border-gray-600 bg-gray-700/50 hover:border-gray-500'
                    }`}
                  >
                    {pInfo.highlight && (
                      <span className={`absolute -top-2 right-2 text-[9px] font-bold bg-gradient-to-r ${pInfo.color} text-white px-1.5 py-0.5 rounded-full`}>
                        {pInfo.highlight}
                      </span>
                    )}
                    <div className="font-semibold text-white text-sm">{pInfo.name}</div>
                    <div className="text-[10px] text-gray-400 mt-1 leading-tight">{pInfo.tagline}</div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Provider Tips */}
          {provider === 'openrouter' && (
            <div className="flex items-start gap-2.5 bg-purple-500/10 border border-purple-500/20 rounded-lg p-3">
              <Sparkles className="w-4 h-4 text-purple-400 mt-0.5 shrink-0" />
              <p className="text-xs text-purple-300 leading-relaxed">
                <strong>Best for free usage!</strong> OpenRouter has 29+ free models including Llama 3.3 70B, Devstral 2, Nemotron, DeepSeek R1, and more. No credit card needed. Free models have <code className="bg-purple-800/50 px-1 rounded">:free</code> in their name.
              </p>
            </div>
          )}

          {provider === 'gemini' && (
            <div className="flex items-start gap-2.5 bg-green-500/10 border border-green-500/20 rounded-lg p-3">
              <Zap className="w-4 h-4 text-green-400 mt-0.5 shrink-0" />
              <p className="text-xs text-green-300 leading-relaxed">
                <strong>Best for large scripts!</strong> Gemini's free tier supports up to 1 million tokens — perfect for scripts with thousands of lines.
              </p>
            </div>
          )}

          {provider === 'groq' && (
            <div className="flex items-start gap-2.5 bg-amber-500/10 border border-amber-500/20 rounded-lg p-3">
              <Zap className="w-4 h-4 text-amber-400 mt-0.5 shrink-0" />
              <p className="text-xs text-amber-300 leading-relaxed">
                <strong>Fastest inference!</strong> Groq is extremely fast but has token limits on free tier. For large scripts, use Llama 3.1 8B or switch to Gemini/OpenRouter.
              </p>
            </div>
          )}

          {provider === 'openai' && (
            <div className="flex items-start gap-2.5 bg-emerald-500/10 border border-emerald-500/20 rounded-lg p-3">
              <Zap className="w-4 h-4 text-emerald-400 mt-0.5 shrink-0" />
              <p className="text-xs text-emerald-300 leading-relaxed">
                <strong>Paid API.</strong> Requires an OpenAI account with billing enabled. GPT-4.1 is their latest and best model for coding tasks.
              </p>
            </div>
          )}

          {/* API Key */}
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">API Key</label>
            <input
              type="password"
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              placeholder={info?.keyPrefix}
              className="w-full bg-gray-900 border border-gray-600 rounded-lg px-4 py-3 text-gray-200 text-sm font-mono focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none placeholder:text-gray-600"
            />
            <div className="mt-2 flex items-start gap-2">
              <ShieldCheck className="w-4 h-4 text-green-500 mt-0.5 shrink-0" />
              <p className="text-xs text-gray-500">
                Your key stays in your browser. Never sent anywhere except your chosen AI provider.
              </p>
            </div>
            <a
              href={info?.keyUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 mt-2 text-xs text-blue-400 hover:text-blue-300 transition-colors"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              Get your {provider === 'openai' ? '' : 'free'} {info?.name} API key
            </a>
          </div>

          {/* Model Select */}
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Model <span className="text-gray-500">({models.length} available)</span>
            </label>
            <div className="relative">
              <select
                value={model}
                onChange={(e) => setModel(e.target.value)}
                className="w-full bg-gray-900 border border-gray-600 rounded-lg px-4 py-3 text-gray-200 text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none appearance-none cursor-pointer"
              >
                {models.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.label} — {m.note}
                  </option>
                ))}
              </select>
              <ChevronDown className="w-4 h-4 text-gray-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-gray-700 flex items-center justify-end gap-3">
          <button
            onClick={onClose}
            className="px-5 py-2.5 text-sm font-medium text-gray-400 hover:text-white transition-colors rounded-lg hover:bg-gray-700"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            disabled={!apiKey.trim()}
            className="px-6 py-2.5 text-sm font-bold bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white rounded-lg transition-colors"
          >
            Save Settings
          </button>
        </div>
      </div>
    </div>
  );
}
