import { useState, useRef } from 'react';
import { Sparkles, FileCode2, Upload, Trash2, Code2, AlertCircle, AlertTriangle } from 'lucide-react';
import { estimateTokens } from '../utils/ai';

interface WorkspaceProps {
  onGenerate: (prompt: string) => void;
  onEdit: (code: string, prompt: string) => void;
  isGenerating: boolean;
  hasApiKey: boolean;
  onOpenSettings: () => void;
}

export default function Workspace({ onGenerate, onEdit, isGenerating, hasApiKey, onOpenSettings }: WorkspaceProps) {
  const [activeTab, setActiveTab] = useState<'generate' | 'edit'>('generate');
  const [prompt, setPrompt] = useState('');
  const [existingCode, setExistingCode] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result;
      if (typeof result === 'string') {
        setExistingCode(result);
      }
    };
    reader.readAsText(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!hasApiKey) {
      onOpenSettings();
      return;
    }
    if (activeTab === 'generate' && prompt.trim()) {
      onGenerate(prompt.trim());
    } else if (activeTab === 'edit' && existingCode.trim() && prompt.trim()) {
      onEdit(existingCode, prompt.trim());
    }
  };

  const isSubmitDisabled =
    isGenerating ||
    (activeTab === 'generate' ? !prompt.trim() : !prompt.trim() || !existingCode.trim());

  const lineCount = existingCode.split('\n').length;
  const charCount = existingCode.length;
  const estimatedTkns = activeTab === 'edit' ? estimateTokens(existingCode + prompt) : estimateTokens(prompt);

  return (
    <div className="bg-gray-800 rounded-xl border border-gray-700 flex flex-col overflow-hidden h-full">
      {/* Tabs */}
      <div className="flex border-b border-gray-700 bg-gray-800/50">
        <button
          onClick={() => setActiveTab('generate')}
          className={`flex-1 py-3.5 flex items-center justify-center gap-2 text-sm font-medium transition-colors relative ${
            activeTab === 'generate' ? 'text-blue-400 bg-gray-800' : 'text-gray-400 hover:text-gray-200 hover:bg-gray-700/50'
          }`}
        >
          <Sparkles className="w-4 h-4" />
          Generate New Script
          {activeTab === 'generate' && <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-blue-500" />}
        </button>
        <button
          onClick={() => setActiveTab('edit')}
          className={`flex-1 py-3.5 flex items-center justify-center gap-2 text-sm font-medium transition-colors relative ${
            activeTab === 'edit' ? 'text-blue-400 bg-gray-800' : 'text-gray-400 hover:text-gray-200 hover:bg-gray-700/50'
          }`}
        >
          <FileCode2 className="w-4 h-4" />
          Edit Existing Script
          {activeTab === 'edit' && <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-blue-500" />}
        </button>
      </div>

      <form onSubmit={handleSubmit} className="p-5 flex-1 flex flex-col gap-4 overflow-y-auto custom-scrollbar">
        {/* No API Key Warning */}
        {!hasApiKey && (
          <button
            type="button"
            onClick={onOpenSettings}
            className="flex items-center gap-3 bg-amber-500/10 border border-amber-500/20 text-amber-400 rounded-lg p-4 text-left hover:bg-amber-500/15 transition-colors"
          >
            <AlertTriangle className="w-5 h-5 shrink-0" />
            <div>
              <div className="text-sm font-semibold">API Key Required</div>
              <div className="text-xs text-amber-400/70 mt-0.5">
                Click here to set up your free Google Gemini or Groq API key.
              </div>
            </div>
          </button>
        )}

        {/* Script Input (Edit mode) */}
        {activeTab === 'edit' && (
          <div className="flex flex-col gap-2 flex-1 min-h-[200px]">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-gray-300 flex items-center gap-2">
                <Code2 className="w-4 h-4 text-gray-400" />
                Your Script
                {existingCode && (
                  <span className="text-xs text-gray-500 font-normal">
                    ({lineCount} lines · {charCount.toLocaleString()} chars · ~{estimateTokens(existingCode).toLocaleString()} tokens)
                  </span>
                )}
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="file"
                  accept=".lua,.txt"
                  ref={fileInputRef}
                  onChange={handleFileUpload}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="text-xs flex items-center gap-1 bg-gray-700 hover:bg-gray-600 text-gray-200 px-3 py-1.5 rounded-lg transition-colors"
                >
                  <Upload className="w-3.5 h-3.5" />
                  Upload .lua
                </button>
                {existingCode && (
                  <button
                    type="button"
                    onClick={() => setExistingCode('')}
                    className="text-xs flex items-center gap-1 bg-red-900/30 hover:bg-red-900/50 text-red-400 px-3 py-1.5 rounded-lg transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    Clear
                  </button>
                )}
              </div>
            </div>
            <textarea
              value={existingCode}
              onChange={(e) => setExistingCode(e.target.value)}
              placeholder="Paste your Roblox Studio Lua script here or upload a .lua file..."
              className="w-full flex-1 bg-gray-900 border border-gray-700 rounded-lg p-4 font-mono text-sm text-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none resize-none min-h-[180px]"
              spellCheck={false}
            />
            {charCount > 50000 && (
              <div className="flex items-center gap-2 text-xs text-amber-400 bg-amber-400/10 p-2.5 rounded-lg">
                <AlertCircle className="w-4 h-4 shrink-0" />
                Large script ({Math.round(charCount / 1000)}k chars, ~{estimateTokens(existingCode).toLocaleString()} tokens). Use Google Gemini for best results with large scripts.
              </div>
            )}
          </div>
        )}

        {/* Prompt Input */}
        <div className="flex flex-col gap-2 mt-auto">
          <label className="text-sm font-medium text-gray-300 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-blue-400" />
            {activeTab === 'generate'
              ? 'What script do you want to create?'
              : 'What changes should the AI make to your script?'}
          </label>
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder={
              activeTab === 'generate'
                ? 'e.g. Create a round-based minigame system with a lobby, countdown timer, and score tracking...'
                : 'e.g. Add a VIP gamepass check, when a player joins check if they own gamepass ID 123456 and give them 2x coins...'
            }
            className="w-full h-28 bg-gray-900 border border-gray-700 rounded-lg p-4 text-gray-200 text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none resize-none"
            spellCheck={false}
          />
        </div>

        {/* Token estimate */}
        {(prompt.trim() || existingCode.trim()) && (
          <div className="text-xs text-gray-500 flex items-center gap-1.5">
            <span>Estimated request: ~{estimatedTkns.toLocaleString()} tokens</span>
          </div>
        )}

        {/* Submit */}
        <button
          type="submit"
          disabled={isSubmitDisabled && hasApiKey}
          className={`w-full py-3.5 rounded-lg flex items-center justify-center gap-2 font-medium transition-all shadow-lg text-sm ${
            !hasApiKey
              ? 'bg-amber-600 hover:bg-amber-500 text-white shadow-amber-600/20'
              : isSubmitDisabled
              ? 'bg-gray-700 text-gray-500 cursor-not-allowed'
              : 'bg-blue-600 hover:bg-blue-500 text-white shadow-blue-500/20 hover:shadow-blue-500/40'
          }`}
        >
          {isGenerating ? (
            <span className="flex items-center gap-2">
              <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              AI is working...
            </span>
          ) : !hasApiKey ? (
            <span className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5" />
              Set Up API Key First
            </span>
          ) : (
            <span className="flex items-center gap-2">
              {activeTab === 'generate' ? <Sparkles className="w-5 h-5" /> : <FileCode2 className="w-5 h-5" />}
              {activeTab === 'generate' ? 'Generate Script' : 'Apply Changes to Script'}
            </span>
          )}
        </button>
      </form>
    </div>
  );
}
