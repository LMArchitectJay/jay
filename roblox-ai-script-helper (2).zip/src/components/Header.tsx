import { Bot, Code2, Settings, CheckCircle2, AlertTriangle } from 'lucide-react';

interface HeaderProps {
  onOpenSettings: () => void;
  isConnected: boolean;
  providerName: string;
  modelName: string;
}

export default function Header({ onOpenSettings, isConnected, providerName, modelName }: HeaderProps) {
  return (
    <header className="bg-gray-800 border-b border-gray-700 px-4 py-3 sticky top-0 z-10">
      <div className="container mx-auto flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="bg-blue-600 p-2 rounded-lg shadow-lg shadow-blue-600/20">
            <Bot className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-white flex items-center gap-2">
              Roblox Studio AI Script Helper
            </h1>
            <p className="text-xs text-gray-400">Generate, edit, and improve Lua scripts with real AI</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="hidden sm:flex items-center gap-1.5 text-xs text-gray-500">
            <Code2 className="w-3.5 h-3.5" />
            Luau
          </div>

          {isConnected ? (
            <div className="hidden sm:flex items-center gap-1.5 bg-green-500/10 text-green-400 text-xs px-3 py-1.5 rounded-full border border-green-500/20">
              <CheckCircle2 className="w-3.5 h-3.5" />
              {providerName} / {modelName}
            </div>
          ) : (
            <div className="hidden sm:flex items-center gap-1.5 bg-amber-500/10 text-amber-400 text-xs px-3 py-1.5 rounded-full border border-amber-500/20">
              <AlertTriangle className="w-3.5 h-3.5" />
              No API Key
            </div>
          )}

          <button
            onClick={onOpenSettings}
            className="p-2.5 hover:bg-gray-700 rounded-lg transition-colors text-gray-400 hover:text-white"
            title="AI Settings"
          >
            <Settings className="w-5 h-5" />
          </button>
        </div>
      </div>
    </header>
  );
}
