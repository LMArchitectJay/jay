import { useState, useEffect, useRef } from 'react';
import { Copy, CheckCheck, Code2, Download, AlertCircle } from 'lucide-react';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism';

interface OutputPanelProps {
  code: string;
  isGenerating: boolean;
  error: string | null;
}

export default function OutputPanel({ code, isGenerating, error }: OutputPanelProps) {
  const [copied, setCopied] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (copied) {
      const timeout = setTimeout(() => setCopied(false), 2000);
      return () => clearTimeout(timeout);
    }
  }, [copied]);

  // Auto-scroll to bottom during generation
  useEffect(() => {
    if (isGenerating && scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [code, isGenerating]);

  const handleCopy = () => {
    if (!code) return;
    navigator.clipboard.writeText(code);
    setCopied(true);
  };

  const handleDownload = () => {
    if (!code) return;
    const blob = new Blob([code], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'script.lua';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const lineCount = code ? code.split('\n').length : 0;

  return (
    <div className="bg-gray-800 rounded-xl border border-gray-700 flex flex-col h-full overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 bg-gray-800/80 border-b border-gray-700">
        <div className="flex items-center gap-2 text-sm font-medium text-gray-300">
          <Code2 className="w-4 h-4 text-blue-400" />
          Output Script
          {code && !isGenerating && (
            <span className="text-xs text-gray-500 font-normal">({lineCount} lines)</span>
          )}
          {isGenerating && (
            <span className="flex items-center gap-1.5 text-xs text-blue-400 font-normal">
              <span className="w-2 h-2 bg-blue-400 rounded-full animate-pulse" />
              Streaming...
            </span>
          )}
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleCopy}
            disabled={!code || isGenerating}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg bg-gray-700 hover:bg-gray-600 text-gray-200 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
          >
            {copied ? <CheckCheck className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
            {copied ? 'Copied!' : 'Copy'}
          </button>
          <button
            onClick={handleDownload}
            disabled={!code || isGenerating}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg bg-gray-700 hover:bg-gray-600 text-gray-200 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <Download className="w-3.5 h-3.5" />
            Download .lua
          </button>
        </div>
      </div>

      {/* Content */}
      <div ref={scrollRef} className="flex-1 relative bg-[#1e1e1e] overflow-auto custom-scrollbar">
        {/* Error Display */}
        {error && (
          <div className="m-4 bg-red-500/10 border border-red-500/20 text-red-300 rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <AlertCircle className="w-5 h-5 text-red-400 shrink-0" />
              <span className="text-sm font-bold text-red-400">Error</span>
            </div>
            <pre className="text-xs text-red-300/90 whitespace-pre-wrap font-sans leading-relaxed">
              {error}
            </pre>
          </div>
        )}

        {code ? (
          <SyntaxHighlighter
            language="lua"
            style={vscDarkPlus}
            customStyle={{
              margin: 0,
              padding: '1.25rem',
              background: 'transparent',
              fontSize: '13px',
              fontFamily: "'JetBrains Mono', 'Fira Code', Consolas, monospace",
            }}
            showLineNumbers
            wrapLongLines
          >
            {code}
          </SyntaxHighlighter>
        ) : !error ? (
          <div className="absolute inset-0 flex flex-col items-center justify-center text-gray-500 gap-4 p-8">
            <Code2 className="w-14 h-14 opacity-15" />
            <div className="text-center">
              <p className="text-sm font-medium text-gray-400">No output yet</p>
              <p className="text-xs text-gray-600 mt-1 max-w-xs">
                Generate a new script or paste your existing script and tell the AI what to change. The full updated script will appear here.
              </p>
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
}
